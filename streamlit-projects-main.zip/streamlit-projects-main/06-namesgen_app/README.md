### Streamlit-Projects
+ App Challenges

#### App Details
+ Name: NamesGenerator App
+ Description: generate random names/petnames and random list


#### Pkg Requirements
+ streamlit
+ names
+ random
+ petnames*
