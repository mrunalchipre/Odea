### Streamlit-Projects
+ 7 Days of Streamlit Apps


#### Day 2: Password Generation App
***Description*** : Generate Random Passwords and NATO phonetics of the generated password

***Function***: Randomly Generate Password from Alphanumeric characters


#### Requirements
+ streamlit
+ random
+ nato phonetics dictionary



#### Maintainer
+ Jesse E.Agbe(JCharis)
+ Jesus Saves @JCharisTech

